RUNAWAY AE1

Abrir index.html en el navegador.
Archivos requeridos: index.html, listado_box.html, producto.html y comprar.html.
El diseño utiliza HTML y CSS como lenguajes principales.
