// RUNAWAY - TP2 JavaScript Vanilla
// Parte A: lectura de dos valores, suma y actualización dinámica del DOM.

const valor1 = document.getElementById("valor1");
const valor2 = document.getElementById("valor2");
const botonCalcular = document.getElementById("botonCalcular");
const resultado = document.getElementById("resultado");

if (valor1 && valor2 && botonCalcular && resultado) {
    botonCalcular.addEventListener("click", function () {
        const numero1 = Number(valor1.value);
        const numero2 = Number(valor2.value);
        const suma = numero1 + numero2;

        let estado = "cero";

        if (suma > 0) {
            estado = "positivo";
        } else if (suma < 0) {
            estado = "negativo";
        }

        resultado.textContent = suma + " (" + estado + ")";
        resultado.className = "resultado " + estado;
    });
}

// Parte B: cálculo del subtotal del producto en tiempo real.

const cantidadProducto = document.getElementById("cantidadProducto");
const subtotalProducto = document.getElementById("subtotalProducto");
const totalProducto = document.getElementById("totalProducto");
const productos = document.getElementById("productos");

if (cantidadProducto && subtotalProducto && totalProducto) {
    const precioUnitario = 245000;

    function actualizarSubtotal() {
        let cantidad = Number(cantidadProducto.value);

        if (cantidad < 1) {
            cantidad = 1;
            cantidadProducto.value = 1;
        }

        const subtotal = cantidad * precioUnitario;
        const subtotalFormateado = "$" + subtotal.toLocaleString("es-AR");

        subtotalProducto.textContent = subtotalFormateado;
        totalProducto.textContent = subtotalFormateado;

        if (productos) {
            productos.value = cantidad + " x Nocturne Hoodie / Talle M / " + subtotalFormateado;
        }
    }

    cantidadProducto.addEventListener("input", actualizarSubtotal);
    actualizarSubtotal();
}
