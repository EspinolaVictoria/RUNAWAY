RUNAWAY - TP2 JavaScript Vanilla

Contenido del proyecto:
- index.html: portada principal del TP1.
- listado_box.html: catálogo en forma de tabla.
- producto.html: ficha de producto.
- comprar.html: formulario de compra con cálculo dinámico de subtotal.
- algoritmica.html: Parte A de la consigna, con dos valores numéricos, suma y clasificación del resultado.
- style.css: estilos generales y responsive.
- script.js: comportamiento JavaScript Vanilla.

PARTE A
Abrir algoritmica.html. Se ingresan dos números y, al presionar “Calcular suma”, JavaScript lee ambos valores, calcula la suma y actualiza el nodo <span id="resultado"> indicando si el resultado es positivo, cero o negativo.

PARTE B
Abrir comprar.html. El campo Cantidad es un <input type="number">. Cada cambio dispara el evento input y recalcula el subtotal y total en pantalla sin recargar la página. También se actualiza el listado de productos del formulario.

No se utilizaron frameworks ni librerías externas. El comportamiento fue desarrollado con JavaScript Vanilla y manipulación directa del DOM.
